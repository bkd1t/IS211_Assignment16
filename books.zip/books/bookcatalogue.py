from flask import Flask, render_template, redirect, url_for, request, session
import requests
import json
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, static_url_path='/assets')
app.config['SECRET_KEY'] = 'configure strong secret key here'

@app.route('/delete/<pk>', methods = ['POST', 'GET'])
def delete(pk):
    id=pk
    print id
    con = sqlite3.connect("database.db")
    with con:
        cur = con.cursor()
        cur.execute('DELETE FROM books WHERE id = (?)', (id,))
        con.commit()
    return redirect('/books')
    
@app.route('/', methods = ['POST', 'GET'])
def index():
    if ("username" in session):
        return redirect('/form')
    else:
        return redirect('/books')
@app.route('/form', methods = ['POST', 'GET'])
def form():
    return render_template('form.html')

@app.route('/register', methods = ['POST', 'GET'])
def register():
    return render_template('register.html')

@app.route('/books', methods = ['POST', 'GET'])
def books():
    if "username" in session:

        con = sqlite3.connect("database.db")
        with con:
            cur = con.cursor()
            cur.execute('SELECT * from books where username=?',(session["username"],))
            con.commit()
        rows = cur.fetchall(); 
        if (len(rows)==0):
            return render_template('books.html', items_available=False, message="You've not added any books")
        return render_template('books.html', rows=rows,items_available=True)
    else:
        return redirect("/form")
@app.route('/signup', methods = ['POST', 'GET'])
def singup():
    if not request.json:
        print "Test"
    item = request.json
    username = item["username"]
    password = item["password"]
    print(username)
    print(password)
    hashed_pwd = generate_password_hash(password, 'sha256')
    print(hashed_pwd)
    con = sqlite3.connect("database.db")
    with con:
        cur = con.cursor()
        cur.execute('INSERT INTO users( username, password) VALUES(?, ?)', ( username, hashed_pwd))
        con.commit()
        return json.dumps({"message": "success"})


@app.route('/login', methods = ['POST', 'GET'])
def login():
    if not request.json:
        print "Test"
    item = request.json
    username = item["username"]
    password = item["password"]
    print username
    print password
    con = sqlite3.connect("database.db")
    with con:
        cur = con.cursor()
        rows = cur.execute('SELECT password from users where username=?',(username,))
        try:
            hashed_pwd = rows.fetchall()[0][0]
            print hashed_pwd
        except:
            return json.dumps({"message": "Invalid Credentials"})
        if check_password_hash(hashed_pwd, password) == True:
            session['username'] = username
            return json.dumps({"message":"success","username": session["username"]})
        else:
            return json.dumps({"message": "Invalid Credentials"})
        return json.dumps({"message": "Please Register before loggin in"})


@app.route('/add', methods = ['POST', 'GET'])
def add():
    if not request.json:
        abort(400)
    item = request.json
    print item["title"]
    con = sqlite3.connect("database.db")
    with con:
        cur = con.cursor()

        cur.execute('INSERT INTO books(title, authors,average_rating, page_count, thumbnail, username) VALUES(?, ?, ?, ?, ?, ?)', ( str(item["title"]), str(item["authors"]), str(item["average_rating"]), str(item["page_count"]), str(item["thumbnail"]), session["username"]))
        con.commit()
        return json.dumps({"message": "success"})

    return redirect('/search')


@app.route('/search',methods = ['POST', 'GET'])
def search():
    # if request.method == 'POST':
    #     isbn = request.form['isbn']
    if "username" not in session:
        return redirect("/form")
    if request.method == 'POST':
        search_by = request.form['search']
        search_key = request.form['key']
        if(search_by=="isbn"):
            response = requests.get('https://www.googleapis.com/books/v1/volumes?q=isbn:'+search_key)
            # print (response.json())
            totalItems = response.json()["totalItems"]
            if(totalItems==0):
                return render_template('book_search.html', items_available=False, message="No Results Found")

            output_items = response.json()["items"]

            items = []

            for i in output_items:
                authors = ""
                try:
                    for a in range(0, len(i["volumeInfo"]["authors"])):
                        if(a>0):
                            authors = authors + "," + i["volumeInfo"]["authors"][a]
                        else:
                            authors = i["volumeInfo"]["authors"][a]

                except:
                    authors = "NA"
                try:
                    average_rating = i["volumeInfo"]["averageRating"]
                except:
                    average_rating = "NA"

                try:
                    page_count = i["volumeInfo"]["pageCount"]
                except:
                    page_count = "NA"

                try:
                    thumbnail = i["volumeInfo"]["imageLinks"]["thumbnail"]
                except:
                    thumbnail = "NA"
                title = i["volumeInfo"]["title"]

                item = {"authors": authors, "page_count": page_count, "average_rating":average_rating, "title":title, "thumbnail": thumbnail}
                items.append(item)
            print(len(items))
        elif (search_by == "title"):
            url = "https://www.googleapis.com/books/v1/volumes?q="+search_key+"&key=AIzaSyD7hdMwfwGfOGxEiH73UXMCEZ460i2hk0E"
            response = requests.get(url)
            # print (response.json())
            totalItems = response.json()["totalItems"]
            if(totalItems==0):
                return render_template('book_search.html', items_available=False, message="No Results Found")
            output_items = response.json()["items"]
            items = []

            for i in output_items:
                authors = ""
                try:
                    if len(i["volumeInfo"]["authors"]) > 0:
                        for a in range(0, len(i["volumeInfo"]["authors"])):
                            if (a>0):
                                authors = authors + "," + i["volumeInfo"]["authors"][a]
                            else:
                                authors = i["volumeInfo"]["authors"][a]

                    else:
                        authors = i["volumeInfo"]["authors"]
                except:
                    authors = "NA"
                try:
                    average_rating = i["volumeInfo"]["averageRating"]
                except:
                    average_rating = "NA"
                try:
                    average_rating = i["volumeInfo"]["averageRating"]
                except:
                    average_rating = "NA"

                try:
                    page_count = i["volumeInfo"]["pageCount"]
                except:
                    page_count = "NA"

                try:
                    thumbnail = i["volumeInfo"]["imageLinks"]["thumbnail"]
                except:
                    thumbnail = "NA"

                title = i["volumeInfo"]["title"]
                item = {"authors": authors, "page_count": page_count, "average_rating":average_rating, "title":title, "thumbnail": thumbnail}
                items.append(item)
    # con = sqlite3.connect("database.db")
    # id = None
    # with con:
    #     cur = con.cursor()
    #     cur.execute('INSERT INTO todo VALUES(?, ?, ?, ?)', (id, name, email, priority))
    #     con.commit()

    # con = sqlite3.connect("database.db")
    # con.row_factory = sqlite3.Row
    # cur = con.cursor()
    # cur.execute("select * from todo")
    # rows = cur.fetchall(); 

        return render_template('book_search.html', items=items, items_available=True)
    return render_template('book_search.html')
    # else:

    #     return render_template('create_todo.html')
    


if __name__=='__main__':
    import sqlite3
    conn = sqlite3.connect('database.db')
    conn.execute('CREATE table if not exists books (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, title text NOT NULL, authors varchar, average_rating varchar, page_count varchar, thumbnail varchar, username varchar)')
    conn.execute('CREATE table if not exists users (username  varchar PRIMARY KEY NOT NULL, password varchar NOT NULL)')
    conn.close()
    app.run()
    # export FLASK_ENV=development



# from flask import Flask, render_template
# app = Flask(__name__)

# @app.route('/')
# def index():
#     return 'Index Page'

# @app.route('/hello')
# def hello():
#     name=None
#     return render_template('hello.html', name=name)