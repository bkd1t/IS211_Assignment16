
class BookForm(Form):
    # media_types = [('Digital', 'Digital'),
    #                ('CD', 'CD'),
    #                ('Cassette Tape', 'Cassette Tape')
    #                ]
    # artist = StringField('Artist')
    # title = StringField('Title')
    # release_date = StringField('Release Date')
    name = StringField('name')
    # media_type = SelectField('Media', choices=media_types)